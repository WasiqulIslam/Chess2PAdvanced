Please run this program by double-clicking the 'Play.bat' file (in Windows systems).

If you use Linux or Mac, please get in touch with me to learn how to play it.

Please set your primary monitor's screen resolution to 800 X 600 pixels before playing the game to play it in Fullscreen mode. Otherwise, it may play in a small window.

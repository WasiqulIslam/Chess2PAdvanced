Readme about these images:
The images of the pieces have transparent background.
So it does not effect the board.
These images are fully created by Flash 8(by Exporting from Flash).